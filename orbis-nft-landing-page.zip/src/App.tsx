import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Monitor, Palette, Zap } from 'lucide-react';
import CardCarousel from './components/CardCarousel';
import FeatureCard from './components/FeatureCard';

// ─── Custom brand icons ───────────────────────────────────────────────────────
function TwitterIcon({ size = 20, color = 'currentColor' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.261 5.635 5.903-5.635zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

function GithubIcon({ size = 20, color = 'currentColor' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
    </svg>
  );
}

// ─── Data ─────────────────────────────────────────────────────────────────────
const NFT_CARDS = [
  {
    video: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260331_053923_22c0a6a5-313c-474c-85ff-3b50d25e944a.mp4',
    score: '8.7/10',
  },
  {
    video: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260331_054411_511c1b7a-fb2f-42ef-bf6c-32c0b1a06e79.mp4',
    score: '9/10',
  },
  {
    video: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260331_055427_ac7035b5-9f3b-4289-86fc-941b2432317d.mp4',
    score: '8.2/10',
  },
];

const FEATURE_CARDS = [
  {
    title: 'Hardware',
    description: 'My entire desktop setup is built for power. It is silent, durable, and holds my focus.',
    icon: <Monitor size={32} strokeWidth={2.5} />,
    gradient: 'linear-gradient(137deg, #FF3D77 0%, #FFB1CE 45%, #FF9D3C 100%)',
    delay: 0.1,
  },
  {
    title: 'Studio',
    description: 'Studio is where I define every single pixel. It is the hub for each canvas I deliver.',
    icon: <Palette size={32} strokeWidth={2.5} />,
    gradient: 'linear-gradient(137deg, #FFFFFF 0%, #7DD3FC 45%, #06B6D4 100%)',
    delay: 0.2,
  },
  {
    title: 'Motion',
    description: 'I use Motion to build lively prototypes, bridging the gap between views and code.',
    icon: <Zap size={32} strokeWidth={2.5} />,
    gradient: 'linear-gradient(137deg, #4361EE 0%, #E0AEFF 45%, #F72585 100%)',
    delay: 0.3,
  },
];

// ─── Chevron SVG ──────────────────────────────────────────────────────────────
function ChevronRight() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 18l6-6-6-6" />
    </svg>
  );
}

// ─── Social Buttons ───────────────────────────────────────────────────────────
const SOCIAL_ICONS = [
  <Mail size={20} color="#EFF4FF" />,
  <TwitterIcon size={20} color="#EFF4FF" />,
  <GithubIcon size={20} color="#EFF4FF" />,
];

function SocialIcons({ direction = 'col' }: { direction?: 'col' | 'row' }) {
  return (
    <div className={`flex ${direction === 'col' ? 'flex-col' : 'flex-row'} gap-3`}>
      {SOCIAL_ICONS.map((icon, i) => (
        <button
          key={i}
          className="liquid-glass rounded-[1rem] flex items-center justify-center hover:bg-white/10 transition-all duration-200"
          style={{ width: 56, height: 56, flexShrink: 0 }}
        >
          {icon}
        </button>
      ))}
    </div>
  );
}

// ─── TEXTURE OVERLAY ─────────────────────────────────────────────────────────
function TextureOverlay() {
  return (
    <div
      className="fixed inset-0 z-50 pointer-events-none select-none"
      style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
        backgroundSize: '200px 200px',
        mixBlendMode: 'lighten',
        opacity: 0.06,
      }}
    />
  );
}

// ─── INTRO SCREEN ─────────────────────────────────────────────────────────────
function IntroScreen({ onEnter }: { onEnter: () => void }) {
  return (
    <motion.div
      className="intro-screen fixed inset-0 z-[200] flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 1.2, ease: 'easeInOut' }}
    >
      {/* Stars */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 100 }).map((_, i) => {
          const size = Math.random() * 2.5 + 0.5;
          return (
            <div
              key={i}
              className="absolute rounded-full bg-white"
              style={{
                width: size,
                height: size,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.7 + 0.1,
              }}
            />
          );
        })}
      </div>

      {/* Radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse 60% 60% at 50% 50%, rgba(111,255,0,0.05) 0%, transparent 70%)' }}
      />

      <motion.div
        className="flex flex-col items-center gap-6 z-10 text-center px-6"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.1, delay: 0.2, ease: 'easeOut' }}
      >
        {/* Logo mark */}
        <div
          className="intro-title select-none"
          style={{ fontSize: 'clamp(4rem, 14vw, 10rem)', lineHeight: 1 }}
        >
          𝑍𝑜𝑙𝑑𝑖𝑥
        </div>

        {/* Subtitle */}
        <motion.p
          className="font-mono uppercase tracking-[0.5em] text-cream/40"
          style={{ fontSize: 'clamp(0.55rem, 1.5vw, 0.75rem)' }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.8 }}
        >
          Orbital NFT Experience
        </motion.p>

        {/* Divider */}
        <motion.div
          className="h-px w-24 bg-neon/40"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 1.1, duration: 0.6 }}
        />

        {/* CTA */}
        <motion.button
          onClick={onEnter}
          className="enter-btn mt-2 px-12 py-4 font-grotesk tracking-[0.35em] uppercase text-neon cursor-pointer"
          style={{ borderRadius: '100px', fontSize: 'clamp(0.7rem, 1.5vw, 0.9rem)' }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.7 }}
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.97 }}
        >
          Enter the Void
        </motion.button>
      </motion.div>

      {/* Bottom tagline */}
      <motion.div
        className="absolute bottom-8 left-0 right-0 flex justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 0.6 }}
      >
        <span className="font-mono text-[10px] tracking-[0.3em] uppercase text-cream/20">
          Orbis.Nft — Beyond the familiar
        </span>
      </motion.div>
    </motion.div>
  );
}

// ─── HERO SECTION ─────────────────────────────────────────────────────────────
function HeroSection() {
  return (
    <section id="hero" className="relative w-full min-h-screen rounded-b-[32px] overflow-hidden">
      {/* Video BG */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260331_045634_e1c98c76-1265-4f5c-882a-4276f2080894.mp4"
      />
      {/* Scrim */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/20 to-black/60" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-[1831px] mx-auto px-5 sm:px-8 lg:px-16 min-h-screen flex flex-col">

        {/* ── HEADER ── */}
        <div className="flex items-center justify-between pt-8 lg:pt-10">
          {/* Logo */}
          <span className="font-grotesk text-base text-cream uppercase tracking-wider select-none">
            Orbis.Nft
          </span>

          {/* Nav — desktop */}
          <nav className="hidden lg:block liquid-glass rounded-[28px] px-[52px] py-[24px]">
            <ul className="flex items-center gap-8 list-none">
              {['Homepage', 'Gallery', 'Buy NFT', 'FAQ', 'Contact'].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="font-grotesk text-[13px] uppercase text-cream hover:text-neon transition-colors duration-200 no-underline"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Social — desktop */}
          <div className="hidden lg:flex">
            <SocialIcons direction="col" />
          </div>
        </div>

        {/* ── HERO CONTENT ── */}
        <div className="flex-1 flex flex-col justify-end pb-20 lg:pb-32">
          <div className="relative lg:ml-32 max-w-full lg:max-w-[780px]">
            {/* Nft collection accent */}
            <span
              className="font-condiment text-neon select-none -rotate-1 absolute pointer-events-none"
              style={{
                fontSize: 'clamp(1.5rem, 4vw, 3rem)',
                mixBlendMode: 'exclusion',
                opacity: 0.9,
                top: '-2.5rem',
                right: '0',
              }}
            >
              Nft collection
            </span>

            {/* Main heading */}
            <h1
              className="font-grotesk uppercase text-cream"
              style={{
                fontSize: 'clamp(2.5rem, 8vw, 5.625rem)',
                lineHeight: 1.02,
              }}
            >
              Beyond earth<br />
              and <span style={{ opacity: 0.7 }}>( its )</span> familiar<br />
              boundaries
            </h1>
          </div>

          {/* Social — mobile */}
          <div className="flex lg:hidden justify-center mt-10">
            <SocialIcons direction="row" />
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── ABOUT SECTION ────────────────────────────────────────────────────────────
function AboutSection() {
  const DESC = 'A digital object fixed beyond time and place. An exploration of distance, form, and silence in space';

  return (
    <section id="about" className="relative w-full min-h-screen overflow-hidden">
      {/* Video BG */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260331_151551_992053d1-3d3e-4b8c-abac-45f22158f411.mp4"
      />
      <div className="absolute inset-0 bg-black/45" />

      <div className="relative z-10 w-full max-w-[1831px] mx-auto px-5 sm:px-8 lg:px-16 min-h-screen flex flex-col justify-between py-16 lg:py-24">

        {/* ── TOP ROW ── */}
        <div className="flex flex-col lg:flex-row lg:items-start gap-10 lg:gap-20 pt-8">

          {/* Left heading */}
          <div className="relative flex-shrink-0 pb-4">
            <h2
              className="font-grotesk uppercase text-cream"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.75rem)', lineHeight: 1.05 }}
            >
              Hello!<br />
              I'm orbis
            </h2>
            {/* Orbis cursive overlay */}
            <span
              className="font-condiment text-neon select-none pointer-events-none absolute"
              style={{
                fontSize: 'clamp(2.25rem, 5vw, 4.25rem)',
                mixBlendMode: 'exclusion',
                bottom: '-0.5rem',
                right: '-1rem',
                transform: 'rotate(4deg)',
              }}
            >
              Orbis
            </span>
          </div>

          {/* Right paragraph */}
          <div className="lg:ml-auto" style={{ maxWidth: '266px' }}>
            <p className="font-mono text-[14px] sm:text-base uppercase text-cream leading-relaxed">
              {DESC}
            </p>
          </div>
        </div>

        {/* ── BOTTOM ROW ── */}
        <div className="flex flex-row justify-between pt-16">
          {/* Left decorative */}
          <div className="flex flex-col gap-6" style={{ maxWidth: '266px' }}>
            <p className="font-mono text-[14px] uppercase leading-relaxed" style={{ color: '#010828', opacity: 0.1 }}>
              {DESC}
            </p>
            <p className="font-mono text-[14px] uppercase leading-relaxed" style={{ color: '#010828', opacity: 0.1 }}>
              {DESC}
            </p>
          </div>

          {/* Right decorative — desktop only */}
          <div className="hidden lg:flex flex-col gap-6" style={{ maxWidth: '266px' }}>
            <p className="font-mono text-[14px] uppercase text-cream leading-relaxed" style={{ opacity: 0.1 }}>
              {DESC}
            </p>
            <p className="font-mono text-[14px] uppercase text-cream leading-relaxed" style={{ opacity: 0.1 }}>
              {DESC}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── FEATURE CARDS SECTION ────────────────────────────────────────────────────
function FeatureCardsSection() {
  return (
    <section className="relative w-full py-20 lg:py-28" style={{ backgroundColor: '#010828' }}>
      <div className="w-full max-w-[1831px] mx-auto px-5 sm:px-8 lg:px-16">

        {/* Section label */}
        <div className="mb-16 text-center">
          <p className="font-mono text-[11px] tracking-[0.4em] uppercase text-cream/40 mb-4">
            Capabilities
          </p>
          <h2
            className="font-grotesk uppercase text-cream"
            style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
          >
            Our Stack
          </h2>
          <div className="mt-4 h-[3px] w-14 bg-neon mx-auto rounded-full" />
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-3 lg:gap-3 w-full max-w-[936px] mx-auto">
          {FEATURE_CARDS.map((card) => (
            <FeatureCard key={card.title} {...card} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── NFT COLLECTION SECTION ──────────────────────────────────────────────────
function NFTSection() {
  return (
    <section id="gallery" className="relative w-full py-20 lg:py-28" style={{ backgroundColor: '#010828' }}>
      <div className="w-full max-w-[1831px] mx-auto px-5 sm:px-8 lg:px-16">

        {/* ── HEADER ROW ── */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14 lg:mb-20">

          {/* Left: Heading */}
          <div className="flex-shrink-0">
            <h2
              className="font-grotesk uppercase text-cream"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.75rem)', lineHeight: 1.05 }}
            >
              Collection of
            </h2>
            {/* Second line with indent and layered Space / objects */}
            <div
              className="relative"
              style={{ marginLeft: 'clamp(3rem, 6vw, 8rem)', marginTop: '0.1em' }}
            >
              {/* Condiment "Space" behind */}
              <span
                className="font-condiment text-neon absolute left-0 top-0 leading-none select-none pointer-events-none"
                style={{ fontSize: 'clamp(2rem, 5vw, 3.75rem)' }}
              >
                Space
              </span>
              {/* Anton "objects" — padded left to sit after Space */}
              <h2
                className="font-grotesk uppercase text-cream relative"
                style={{
                  fontSize: 'clamp(2rem, 5vw, 3.75rem)',
                  lineHeight: 1.05,
                  paddingLeft: 'clamp(5rem, 10vw, 9rem)',
                }}
              >
                objects
              </h2>
            </div>
          </div>

          {/* Right: SEE ALL CREATORS */}
          <div className="flex-shrink-0 cursor-pointer group">
            <div className="flex items-baseline gap-3">
              <span
                className="font-grotesk uppercase text-cream group-hover:text-neon transition-colors duration-200"
                style={{ fontSize: 'clamp(2rem, 5vw, 3.75rem)' }}
              >
                SEE
              </span>
              <div className="flex flex-col leading-tight">
                <span
                  className="font-grotesk uppercase text-cream group-hover:text-neon transition-colors duration-200"
                  style={{ fontSize: 'clamp(1.25rem, 2.5vw, 2.25rem)' }}
                >
                  ALL
                </span>
                <span
                  className="font-grotesk uppercase text-cream group-hover:text-neon transition-colors duration-200"
                  style={{ fontSize: 'clamp(1.25rem, 2.5vw, 2.25rem)' }}
                >
                  CREATORS
                </span>
              </div>
            </div>
            {/* Neon underbar */}
            <div
              className="w-full rounded-sm bg-neon mt-2"
              style={{ height: 'clamp(6px, 1vw, 10px)' }}
            />
          </div>
        </div>

        {/* ── GRID ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {NFT_CARDS.map((card, i) => (
            <div
              key={i}
              className="liquid-glass rounded-[32px] hover:bg-white/10 transition-all duration-300 cursor-pointer"
              style={{ padding: '18px' }}
            >
              {/* Square video */}
              <div className="relative w-full rounded-[24px] overflow-hidden" style={{ paddingBottom: '100%' }}>
                <video
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover"
                  src={card.video}
                />
              </div>

              {/* Bottom bar */}
              <div className="liquid-glass rounded-[20px] mt-4 flex items-center justify-between" style={{ padding: '16px 20px' }}>
                <div>
                  <p
                    className="font-mono uppercase text-cream/70"
                    style={{ fontSize: '11px' }}
                  >
                    Rarity Score:
                  </p>
                  <p
                    className="font-mono text-cream font-medium"
                    style={{ fontSize: '16px', marginTop: '2px' }}
                  >
                    {card.score}
                  </p>
                </div>
                <button
                  className="flex items-center justify-center rounded-full hover:scale-110 transition-transform duration-200 flex-shrink-0"
                  style={{
                    width: 48,
                    height: 48,
                    background: 'linear-gradient(135deg, #b724ff 0%, #7c3aed 100%)',
                    boxShadow: '0 10px 40px rgba(168, 85, 247, 0.5)',
                  }}
                >
                  <ChevronRight />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── CAROUSEL SECTION ─────────────────────────────────────────────────────────
function CarouselSection() {
  return (
    <section
      className="relative w-full overflow-hidden"
      style={{ minHeight: '100vh', backgroundColor: '#000000' }}
    >
      {/* Label */}
      <div className="absolute top-0 left-0 right-0 z-20 flex flex-col items-center pt-10 pointer-events-none">
        <p
          className="font-mono uppercase tracking-[0.5em] text-white/25"
          style={{ fontSize: '10px' }}
        >
          Premium Collection
        </p>
        <h2
          className="font-grotesk uppercase text-white/60 mt-1"
          style={{ fontSize: 'clamp(1rem, 2vw, 1.5rem)', letterSpacing: '0.2em' }}
        >
          3D Vault
        </h2>
        <div className="mt-2 h-[1px] w-10 bg-neon/50" />
      </div>

      <CardCarousel />
    </section>
  );
}

// ─── CTA SECTION ─────────────────────────────────────────────────────────────
function CTASection() {
  return (
    <section
      id="contact"
      className="relative w-full overflow-hidden"
      style={{ backgroundColor: '#010828' }}
    >
      {/* Video — native aspect ratio */}
      <div className="relative w-full">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-auto block"
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260331_055729_72d66327-b59e-4ae9-bb70-de6ccb5ecdb0.mp4"
        />

        {/* Overlay */}
        <div className="absolute inset-0">
          <div className="relative w-full h-full max-w-[1831px] mx-auto">

            {/* Text block — right aligned */}
            <div
              className="absolute top-1/2 -translate-y-1/2 right-0 text-right"
              style={{ paddingRight: 'clamp(1.25rem, 20%, 20%)', paddingLeft: 'clamp(1.25rem, 5%, 15%)' }}
            >
              {/* Go beyond accent */}
              <span
                className="font-condiment text-neon select-none pointer-events-none absolute"
                style={{
                  fontSize: 'clamp(1.0625rem, 5vw, 4.25rem)',
                  mixBlendMode: 'exclusion',
                  top: '-3rem',
                  left: 'clamp(1.25rem, 5%, 15%)',
                }}
              >
                Go beyond
              </span>

              <h2
                className="font-grotesk uppercase text-cream"
                style={{ fontSize: 'clamp(1rem, 4vw, 3.75rem)', lineHeight: 1.08 }}
              >
                <span className="block" style={{ marginBottom: 'clamp(1rem, 3vw, 3rem)' }}>
                  JOIN US.
                </span>
                <span className="block">REVEAL WHAT'S HIDDEN.</span>
                <span className="block">DEFINE WHAT'S NEXT.</span>
                <span className="block">FOLLOW THE SIGNAL.</span>
              </h2>
            </div>

            {/* Social icons — bottom-left, vertical, liquid-glass */}
            <div
              className="absolute left-[8%]"
              style={{ bottom: 'clamp(12%, 15%, 20%)' }}
            >
              <div className="liquid-glass overflow-hidden flex flex-col" style={{ borderRadius: 'clamp(0.5rem, 1.5vw, 1.25rem)' }}>
                {SOCIAL_ICONS.map((icon, idx) => (
                  <button
                    key={idx}
                    className="flex items-center justify-center hover:bg-white/10 transition-all duration-200"
                    style={{
                      width: 'clamp(3rem, 14vw, 16.77rem)',
                      height: 'clamp(2.5rem, 9vw, 5rem)',
                      borderBottom: idx < 2 ? '1px solid rgba(255,255,255,0.1)' : 'none',
                    }}
                  >
                    {icon}
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [siteReady, setSiteReady] = useState(false);

  const handleEnter = () => {
    setSiteReady(true);
    setTimeout(() => setShowIntro(false), 1300);
  };

  useEffect(() => {
    if (showIntro && !siteReady) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [showIntro, siteReady]);

  return (
    <div style={{ backgroundColor: '#010828' }}>
      {/* Global noise texture */}
      <TextureOverlay />

      {/* Intro */}
      <AnimatePresence>
        {showIntro && <IntroScreen onEnter={handleEnter} />}
      </AnimatePresence>

      {/* Site content */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: siteReady ? 1 : 0 }}
        transition={{ duration: 1.1, delay: 0.2 }}
      >
        <HeroSection />
        <AboutSection />
        <FeatureCardsSection />
        <NFTSection />
        <CarouselSection />
        <CTASection />
      </motion.div>
    </div>
  );
}
