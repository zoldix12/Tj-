import { motion } from 'motion/react';
import type { ReactNode } from 'react';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  gradient: string;
  delay: number;
}

export default function FeatureCard({ title, description, icon, gradient, delay }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: 'easeOut', delay }}
      className="feature-card-wrapper group"
    >
      {/* Glow background */}
      <div
        className="absolute w-full rounded-[40px] pointer-events-none opacity-60"
        style={{
          height: '260px',
          background: gradient,
          filter: 'blur(45px)',
        }}
      />

      {/* Foreground card with gradient border */}
      <div
        className="relative self-stretch rounded-[40px] z-10 overflow-hidden"
        style={{
          height: '260px',
          border: '8px solid transparent',
          background: `linear-gradient(#1A1A1C, #1A1A1C) padding-box, ${gradient} border-box`,
        }}
      >
        <div className="w-full h-full p-7 flex flex-col justify-between">
          <div className="text-white/90">
            {icon}
          </div>
          <div>
            <h3 className="text-white font-medium text-xl mb-3 tracking-tight">{title}</h3>
            <p className="text-gray-400 text-[14px] leading-[1.6] font-normal selection:bg-white/20">{description}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
